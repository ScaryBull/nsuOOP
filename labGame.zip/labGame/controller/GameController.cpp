#include "GameController.h"
#include <algorithm>


GameController::GameController() : model(), view() {
  for (int i = 0; i < 6; ++i) {
    potionCells.push_back(-1);
  }
}

int GameController::mixIngredients(int ing1, int ing2) {
  if (ing1 == -1 || ing2 == -1)
    return -1;
  return (ing1 + ing2) % 6;
}

void GameController::handleShelfClick(float mouseX, float mouseY) {
  if (showPotion) {
    for (const auto& slot : allSlots) {
      sf::FloatRect bounds(sf::Vector2f(slot.x, slot.y),
        sf::Vector2f(INGREDIENT_SIZE, INGREDIENT_SIZE)
        );
      if (bounds.contains(sf::Vector2f(mouseX, mouseY))) {
        int idx = slot.index;

        if (leftIngredient == idx) {
          leftIngredient = -1;
          model.setIngredientQuantity(idx, model.getIngredientQuantity(idx) + 1);
        }
        else if (rightIngredient == idx) {
          rightIngredient = -1;
          model.setIngredientQuantity(idx, model.getIngredientQuantity(idx) + 1);;
        }
        else if (model.getIngredientQuantity(idx) > 0) {
          if (leftIngredient == -1) {
            leftIngredient = idx;
            model.decrementIngredient(idx);
          } else if (rightIngredient == -1) {
            rightIngredient = idx;
            model.decrementIngredient(idx);
          }
        }
        return;
      }
    }

    float potionX = WINDOW_WIDTH / 2.0f;
    float potionY = WINDOW_HEIGHT / 2.0f;

    if (leftIngredient != -1) {
      float leftIngX = potionX - INGREDIENT_SIZE;
      float leftIngY = potionY - INGREDIENT_SIZE / 6.0f;
      sf::FloatRect leftBounds(sf::Vector2f(leftIngX, leftIngY), sf::Vector2f(INGREDIENT_SIZE, INGREDIENT_SIZE));
      if (leftBounds.contains(sf::Vector2f(mouseX, mouseY))) {
        model.setIngredientQuantity(leftIngredient, model.getIngredientQuantity(leftIngredient) + 1);
        leftIngredient = -1;
        return;
      }
    }

    if (rightIngredient != -1) {
      float rightIngX = potionX;
      float rightIngY = potionY - INGREDIENT_SIZE / 6.0f;
      sf::FloatRect rightBounds(sf::Vector2f(rightIngX, rightIngY), sf::Vector2f(INGREDIENT_SIZE, INGREDIENT_SIZE));
      if (rightBounds.contains(sf::Vector2f(mouseX, mouseY))) {
        model.setIngredientQuantity(rightIngredient, model.getIngredientQuantity(rightIngredient) + 1);
        rightIngredient = -1;
        return;
      }
    }

    if (leftIngredient != -1 && rightIngredient != -1) {
      float buttonX = (WINDOW_WIDTH + POTION_SIZE) / 2.0f - MIX_BUTTON_SIZE - 10;
      float buttonY = (WINDOW_HEIGHT + POTION_SIZE) / 2.0f - MIX_BUTTON_SIZE - 10;
      sf::FloatRect buttonBounds(sf::Vector2f(buttonX, buttonY), sf::Vector2f(MIX_BUTTON_SIZE, MIX_BUTTON_SIZE));
      if (buttonBounds.contains(sf::Vector2f(mouseX, mouseY))) {
        int result = mixIngredients(leftIngredient, rightIngredient);
        for (int i = 0; i < 6; ++i) {
          if (potionCells[i] == -1) {
            potionCells[i] = result;
            break;
          }
        }
        showPotion = false;
        leftIngredient = -1;
        rightIngredient = -1;
        return;
      }
    }
  }
}

void GameController::handleCauldronClick(float mouseX, float mouseY) {
  if (mouseX >= CAULDRON_X && mouseX < CAULDRON_X + CAULDRON_CLICK_SIZE &&
      mouseY >= CAULDRON_Y && mouseY <= CAULDRON_Y + CAULDRON_CLICK_SIZE) {
    if (showPotion) {
      if (leftIngredient != -1)
        model.setIngredientQuantity(leftIngredient, model.getIngredientQuantity(leftIngredient) + 1);
      if (rightIngredient != -1)
        model.setIngredientQuantity(rightIngredient, model.getIngredientQuantity(rightIngredient) + 1);
      showPotion = false;
      leftIngredient = -1;
      rightIngredient = -1;
      //std::fill(potionCells.begin(), potionCells.end(), -1);
    } else if (!showShop) {
      showPotion = true;
    }
      }
}

void GameController::handleShopClick(float mouseX, float mouseY) {
  if (!showPotion && mouseX >= SHOP_X && mouseX <= SHOP_X + SHOP_BUTTON_SIZE &&
    mouseY >= SHOP_Y && mouseY <= SHOP_Y + SHOP_BUTTON_SIZE) {
    showShop = !showShop;
    }
}

void GameController::handleShopBuy(float mouseX, float mouseY) {
  const int SHOP_CELL_SIZE = 70;
  const int COLS = 5;
  const int ROWS = 2;
  const int PADDING = 15;
  const int SPACING = 8;

  const int contentWidth = COLS * SHOP_CELL_SIZE + (COLS - 1) * SPACING;
  const int contentHeight = ROWS * SHOP_CELL_SIZE + (ROWS - 1) * SPACING;
  const int shopWidth = contentWidth + 2 * PADDING;
  const int shopHeight = contentHeight + 2 * PADDING;

  const float shopX = (WINDOW_WIDTH - shopWidth) / 2.0f;
  const float shopY = (WINDOW_HEIGHT / 2.0f + shopHeight) / 2.0f;

  for (int i = 0; i < 6; ++i) {
    int col = i % COLS;
    int row = i / COLS;

    float cellX = shopX + PADDING + col * (SHOP_CELL_SIZE + SPACING);
    float cellY = shopY + PADDING + row * (SHOP_CELL_SIZE + SPACING);

    if (mouseX >= cellX && mouseX < cellX + SHOP_CELL_SIZE &&
      mouseY >= cellY && mouseY < cellY + SHOP_CELL_SIZE) {

      int currentQuantity = model.getIngredientQuantity(i);
      model.setIngredientQuantity(i, currentQuantity + 1);
      return;
      }
  }
}

void GameController::handleEvents(sf::RenderWindow& window) {
  while (const std::optional event = window.pollEvent()) {
    if (event->is<sf::Event::Closed>())
      window.close();

    if (const auto* mouseEvent = event->getIf<sf::Event::MouseButtonPressed>()) {
      if (mouseEvent->button == sf::Mouse::Button::Left) {
        sf::Vector2i mousePos = sf::Mouse::getPosition(window);
        float mouseX = (float)mousePos.x;
        float mouseY = (float)mousePos.y;

        bool handledBuy = false;
        if (showShop)
          handleShopBuy(mouseX, mouseY);

        handleShopClick(mouseX, mouseY);
        if (!showShop) {
          handleCauldronClick(mouseX, mouseY);
          handleShelfClick(mouseX, mouseY);
        }
      }
    }
  }
}

void GameController::draw(sf::RenderWindow& window) {
  view.draw(window, model, showPotion, showShop, leftIngredient, rightIngredient, potionCells, allSlots);
}
