#ifndef LABGAME_GAMECONTROLLER_H
#define LABGAME_GAMECONTROLLER_H

#include <SFML/Graphics.hpp>
#include <SFML/Window/Mouse.hpp>
#include <vector>
#include <optional>
#include "../view/GameView.h"
#include "../model/include/GameModel.h"
#include "../model/include/Potion.h"

namespace {
  constexpr float WINDOW_WIDTH = GameView::WINDOW_WIDTH;
  constexpr float WINDOW_HEIGHT = GameView::WINDOW_HEIGHT;
  constexpr float INGREDIENT_SIZE = GameView::INGREDIENT_SIZE;
  constexpr int SHOP_BUTTON_SIZE = GameView::SHOP_BUTTON_SIZE;
  constexpr float POTION_SIZE = GameView::POTION_SIZE;
  constexpr float CAULDRON_CLICK_SIZE = GameView::CAULDRON_BUTTON_SIZE;
  constexpr float CAULDRON_X = GameView::CAULDRON_X;
  constexpr float CAULDRON_Y = GameView::CAULDRON_Y;
  constexpr float MIX_BUTTON_SIZE = GameView::MIX_BUTTON_SIZE;
  constexpr int SHOP_X = GameView::SHOP_X;
  constexpr int SHOP_Y = GameView::SHOP_Y;
}

class GameController {
private:
  GameModel model;
  GameView view;

  bool showPotion = false;
  bool showShop = false;
  int leftIngredient = -1;
  int rightIngredient = -1;

  std::vector<int> potionCells;
  std::vector<GameView::IngredientSlot> allSlots;

  int mixIngredients(int ing1, int ing2);
  void handleShelfClick(float mouseX, float mouseY);
  void handleCauldronClick(float mouseX, float mouseY);
  void handleCauldronMix();
  void handleShopClick(float mouseX, float mouseY);
  void handleShopBuy(float mouseX, float mouseY);

public:
  GameController();
  void handleEvents(sf::RenderWindow& window);
  void draw(sf::RenderWindow& window);
};

#endif