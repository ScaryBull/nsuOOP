#ifndef LABGAME_INGREDIENT_H
#define LABGAME_INGREDIENT_H

#include <string>
#include "Item.h"

class Ingredient : public Item {
private:
  std::string property;
  int buyPrice;

public:
  Ingredient(const std::string& name, const std::string& property, int buyPrice,
    double sellMultiplier = 1.0, const std::string& imageFile = "");
  std::string getType() const override;
  int getBuyPrice() const override;
  int getPropertyCount() const override;
  int getSellPrice() const override;
  const std::string& getProperty() const;
};

#endif
