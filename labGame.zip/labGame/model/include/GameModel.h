#ifndef LABGAME_GAMEMODEL_H
#define LABGAME_GAMEMODEL_H

#include <algorithm>
#include <map>
#include <vector>
#include "Ingredient.h"
#include "Potion.h"

class GameModel {
private:
  std::vector<Ingredient> allIngredients;
  std::map<int, int> inventory;
  std::vector<Potion> craftedPotions;
  long long gold = 100;

  void initializeIngredients();
  void initializeInventory();

public:
  GameModel();

  int getIngredientQuantity(int index) const;
  void setIngredientQuantity(int index, int quantity) ;
  bool decrementIngredient(int index);
  const Ingredient& getIngredient(int index) const;

  void addPotion(const Potion& potion);
  const std::vector<Potion>& getCraftedPotions() const;
};

#endif
