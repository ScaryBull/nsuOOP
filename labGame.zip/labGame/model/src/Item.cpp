#include "../include/Item.h"

Item::Item(const std::string& name, double sellMultiplier, std::string imageFile)
    : name(name), sellMultiplier(sellMultiplier), imageFile(imageFile) {}

const std::string& Item::getName() const {
  return name;
}

double Item::getSellMultiplier() const {
  return sellMultiplier;
}

const std::string& Item::getImageFileName() const {
  return imageFile;
}