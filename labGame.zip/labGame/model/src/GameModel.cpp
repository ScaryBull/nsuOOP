#include "../include/GameModel.h"


void GameModel::initializeIngredients() {
    allIngredients.emplace_back("Mandragora", "Healing", 10, 1.0, "ingredient_0.png");
    allIngredients.emplace_back("Ginger root", "Energy", 15, 1.0, "ingredient_1.png");
    allIngredients.emplace_back("Manticore ashes", "Strenght", 20, 1.0, "ingredient_2.png");
    allIngredients.emplace_back("Phoenix feather", "Revival", 12, 1.0, "ingredient_3.png");
    allIngredients.emplace_back("Hydra's fang", "Poison", 25, 1.0, "ingredient_4.png");
    allIngredients.emplace_back("Moon mushroom", "Invisibility", 30, 1.0, "ingredient_5.png");
  }

void GameModel::initializeInventory() {
    for (int i = 0; i < 6; ++i) {
      inventory[i] = 5;
    }
  }

GameModel::GameModel() {
  initializeIngredients();
  initializeInventory();
}

int GameModel::getIngredientQuantity(int index) const {
  auto it = inventory.find(index);
  return (it != inventory.end()) ? it->second : 0;
}

void GameModel::setIngredientQuantity(int index, int quantity) {
  inventory[index] = std::max(0, quantity);
}

bool GameModel::decrementIngredient(int index) {
  if (inventory.count(index) && inventory[index] > 0) {
    inventory[index]--;
    return true;
  }
  return false;
}

const Ingredient& GameModel::getIngredient(int index) const {
  return allIngredients.at(index);
}

void GameModel::addPotion(const Potion& potion) {
  craftedPotions.push_back(potion);
}

const std::vector<Potion>& GameModel::getCraftedPotions() const {
  return craftedPotions;
}