#include "../include/Ingredient.h"

Ingredient::Ingredient(const std::string& name, const std::string& property, int buyPrice,
  double sellMultiplier, const std::string& imageFile)
    : Item(name, sellMultiplier, imageFile), property(property), buyPrice(buyPrice) {}

std::string Ingredient::getType() const {
  return "ingredient";
}

int Ingredient::getBuyPrice() const {
  return buyPrice;
}

int Ingredient::getPropertyCount() const {
  return 1;
}

int Ingredient::getSellPrice() const {
  return static_cast<int>(getPropertyCount() * PROPERTY_VALUE * sellMultiplier);
}

const std::string& Ingredient::getProperty() const {
  return property;
}