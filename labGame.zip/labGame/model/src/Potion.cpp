#include "../include/Potion.h"
#include <algorithm>

Potion::Potion(const std::string& name, std::vector<std::string> props,
  double sellMultiplier, const std::string& imageFile)
    : Item(name, sellMultiplier, imageFile), properties(std::move(props)) {}

std::string Potion::getType() const {
  return "potion";
}

int Potion::getBuyPrice() const {
  return 0;
}

int Potion::getPropertyCount() const {
  return static_cast<int>(properties.size());
}

int Potion::getSellPrice() const {
  return static_cast<int>(getPropertyCount() * PROPERTY_VALUE * sellMultiplier);
}

const std::vector<std::string>& Potion::getProperties() const {
  return properties;
}

bool Potion::matchesRecipe(const std::vector<std::string>& input) const {
  if (input.size() != properties.size())
    return false;

  auto a = properties;
  auto b = input;
  std::sort(a.begin(), a.end());
  std::sort(b.begin(), b.end());
  return a == b;
}